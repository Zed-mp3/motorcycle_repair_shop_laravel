﻿<?php
require_once __DIR__ . '/../bootstrap.php';
// work-on-repair.php - Redesigned with dark theme
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || $_SESSION['role'] != 'mechanic') {
    header('Location: ../customer/login.php');
    exit();
}

$conn = getConnection();
$repair_id = $_GET['id'] ?? 0;

$sql = "SELECT r.*, b.booking_id, b.full_name, b.contact_number, b.motorcycle_model, 
        b.problem_description, b.service_type, b.queue_no
        FROM repairs r 
        JOIN bookings b ON r.booking_id = b.id 
        WHERE r.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $repair_id);
$stmt->execute();
$repair = $stmt->get_result()->fetch_assoc();

if (!$repair) {
    header('Location: dashboard.php');
    exit();
}

if (isset($_POST['update_status'])) {
    $new_status = $_POST['status'];
    $update_sql = "UPDATE repairs SET status = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_status, $repair_id);
    $update_stmt->execute();
    
    $booking_status = ($new_status == 'completed') ? 'completed' : ($new_status == 'in_progress' ? 'in_progress' : 'accepted');
    $update_booking = "UPDATE bookings SET status = ? WHERE id = ?";
    $booking_stmt = $conn->prepare($update_booking);
    $booking_stmt->bind_param("si", $booking_status, $repair['booking_id']);
    $booking_stmt->execute();
    
    echo "<script>alert('Status updated successfully!'); window.location.href='work-on-repair.php?id=$repair_id';</script>";
}

if (isset($_POST['add_note'])) {
    $note = $_POST['note'];
    $update_sql = "UPDATE repairs SET notes = CONCAT(IFNULL(notes, ''), ?) WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $date_note = "\n[" . date('Y-m-d H:i') . "] " . $note;
    $update_stmt->bind_param("si", $date_note, $repair_id);
    $update_stmt->execute();
    echo "<script>alert('Note added successfully!'); window.location.href='work-on-repair.php?id=$repair_id';</script>";
}

$parts_sql = "SELECT rp.*, p.part_name, p.unit_price 
              FROM repair_parts rp 
              JOIN parts p ON rp.part_id = p.id 
              WHERE rp.repair_id = ?";
$stmt = $conn->prepare($parts_sql);
$stmt->bind_param("i", $repair_id);
$stmt->execute();
$used_parts = $stmt->get_result();

$parts_total = 0;
$parts_list = [];
while($part = $used_parts->fetch_assoc()) {
    $total = $part['quantity'] * $part['price_at_time'];
    $parts_total += $total;
    $parts_list[] = $part;
}
$used_parts->data_seek(0);

$grand_total = $parts_total + ($repair['labor_cost'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Work on Repair - <?php echo $repair['booking_id']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-color: #e67e22;
            --primary-dark: #c8641a;
            --ink: #16171a;
            --surface: #202227;
            --surface-raised: #2a2c33;
            --chrome: #cfd3d8;
            --chrome-dim: #7d828a;
            --text: #edeff1;
            --text-muted: #9a9ea5;
            --border-steel: rgba(207, 211, 216, 0.12);
        }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--ink); color: var(--text); overflow-x: hidden; }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, var(--surface) 0%, var(--ink) 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.4);
            border-right: 1px solid var(--border-steel);
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid var(--border-steel);
            text-align: center;
        }

        .sidebar-header h3 { margin: 0; font-size: 1.5rem; color: var(--text); }
        .sidebar-header p { margin: 5px 0 0; font-size: 0.8rem; opacity: 0.7; color: var(--text-muted); }

        .sidebar-menu { padding: 20px 0; }

        .menu-item {
            padding: 12px 25px;
            margin: 5px 0;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-left: 3px solid transparent;
        }

        .menu-item:hover { background: rgba(255,255,255,0.06); color: white; border-left-color: var(--primary-color); }
        .menu-item.active { background: rgba(230, 126, 34, 0.15); color: var(--primary-color); border-left-color: var(--primary-color); }
        .menu-item i { width: 25px; font-size: 1.2rem; }

        .main-content { margin-left: 280px; transition: all 0.3s; }

        .top-navbar {
            background: var(--surface);
            padding: 15px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border-steel);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 99;
        }

        .page-title { font-size: 1.2rem; font-weight: 600; color: var(--text); }
        .user-info { display: flex; align-items: center; gap: 15px; color: var(--text); }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .info-card {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .info-card h5 { color: var(--text); }
        .info-card .text-muted-custom { color: var(--text-muted); }

        .notes-history {
            max-height: 200px;
            overflow-y: auto;
            background: var(--surface-raised);
            padding: 12px;
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            white-space: pre-wrap;
            border: 1px solid var(--border-steel);
        }

        .breadcrumb-custom {
            background: transparent;
            padding: 0;
            margin-bottom: 20px;
        }
        .breadcrumb-custom .breadcrumb-item a { color: var(--primary-color); text-decoration: none; }
        .breadcrumb-custom .breadcrumb-item a:hover { color: var(--primary-dark); }
        .breadcrumb-custom .breadcrumb-item.active { color: var(--text-muted); }
        .breadcrumb-custom .breadcrumb-item + .breadcrumb-item::before { color: var(--text-muted); }

        .form-control-dark {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
        }
        .form-control-dark:focus {
            background: var(--surface-raised);
            border-color: var(--primary-color);
            color: var(--text);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }
        .form-control-dark::placeholder { color: var(--text-muted); }

        .form-select-dark {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
        }
        .form-select-dark:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }

        .btn-warning-custom {
            background: var(--primary-color);
            border: none;
            color: white;
            border-radius: 8px;
            padding: 8px 20px;
            transition: all 0.2s;
        }
        .btn-warning-custom:hover { background: var(--primary-dark); color: white; }

        .btn-secondary-custom {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
            padding: 8px 20px;
            transition: all 0.2s;
        }
        .btn-secondary-custom:hover { background: var(--border-steel); color: white; }

        .alert-info-custom {
            background: rgba(13, 110, 253, 0.1);
            border: 1px solid rgba(13, 110, 253, 0.2);
            color: #6ea8fe;
            border-radius: 8px;
            padding: 12px 16px;
        }

        .alert-success-custom {
            background: rgba(25, 135, 84, 0.1);
            border: 1px solid rgba(25, 135, 84, 0.2);
            color: #75b798;
            border-radius: 8px;
            padding: 16px;
        }

        .progress-custom {
            background: var(--surface-raised);
            border-radius: 8px;
            height: 6px;
        }
        .progress-custom .progress-bar {
            background: var(--primary-color);
            border-radius: 8px;
        }

        .table-parts {
            color: var(--text);
        }
        .table-parts thead th {
            border-bottom: 2px solid var(--border-steel);
            color: var(--text-muted);
            font-weight: 500;
            font-size: 0.85rem;
        }
        .table-parts tbody td {
            border-bottom: 1px solid var(--border-steel);
            padding: 8px 10px;
        }
        .table-parts tfoot th {
            border-top: 2px solid var(--border-steel);
            color: var(--text);
            padding: 10px;
        }

        .list-tips i { color: #198754; }
        .list-tips li { padding: 4px 0; color: var(--text-muted); }

        @media (max-width: 768px) {
            .sidebar { left: -280px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                z-index: 1001;
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 6px;
                cursor: pointer;
            }
            .top-navbar { padding-left: 70px; }
        }
        @media (min-width: 769px) { .menu-toggle { display: none; } }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-motorcycle fa-2x mb-2" style="color: var(--primary-color);"></i>
            <h3>MotoRepair Pro</h3>
            <p>Mechanic Portal</p>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="my-repairs.php" class="menu-item"><i class="fas fa-tools"></i><span>My Repairs</span></a>
            <div style="border-top: 1px solid var(--border-steel); margin: 20px 25px;"></div>
            <a href="../logout.php" class="menu-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>

    <div class="main-content" id="mainContent">
        <div class="top-navbar">
            <div class="page-title"><i class="fas fa-wrench" style="color: var(--primary-color);"></i> Working on #<?php echo $repair['booking_id']; ?></div>
            <div class="user-info">
                <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="container mt-4">
            <div class="row">
                <div class="col-md-12">
                    <nav class="breadcrumb-custom">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="my-repairs.php">My Repairs</a></li>
                            <li class="breadcrumb-item active">Repair #<?php echo $repair['booking_id']; ?></li>
                        </ol>
                    </nav>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <!-- Repair Info -->
                    <div class="info-card">
                        <h5 class="mb-3"><i class="fas fa-info-circle" style="color: var(--primary-color);"></i> Repair Information</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Booking ID:</strong> <?php echo $repair['booking_id']; ?></p>
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Customer:</strong> <?php echo htmlspecialchars($repair['full_name']); ?></p>
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Contact:</strong> <?php echo htmlspecialchars($repair['contact_number']); ?></p>
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Queue #:</strong> <?php echo $repair['queue_no']; ?></p>
                            </div>
                            <div class="col-md-6">
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Motorcycle:</strong> <?php echo htmlspecialchars($repair['motorcycle_model']); ?></p>
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Service Type:</strong> <?php echo $repair['service_type']; ?></p>
                                <p style="color: var(--text);"><strong style="color: var(--text-muted);">Started:</strong> <?php echo $repair['start_date'] ?? 'Not started'; ?></p>
                            </div>
                        </div>
                        <div class="alert-info-custom mt-2">
                            <strong style="color: #6ea8fe;">Problem Description:</strong><br>
                            <?php echo nl2br(htmlspecialchars($repair['problem_description'])); ?>
                        </div>
                    </div>

                    <!-- Update Status -->
                    <div class="info-card">
                        <h5 class="mb-3"><i class="fas fa-tasks" style="color: #ffc107;"></i> Update Status</h5>
                        <form method="POST">
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <select name="status" class="form-control form-select-dark" required>
                                        <option value="pending" <?php echo $repair['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="in_progress" <?php echo $repair['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                        <option value="completed" <?php echo $repair['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" name="update_status" class="btn btn-warning-custom w-100">Update</button>
                                </div>
                            </div>
                        </form>
                        <?php if($repair['status'] != 'completed'): ?>
                        <div class="progress mt-3 progress-custom">
                            <div class="progress-bar" style="width: <?php echo $repair['status'] == 'in_progress' ? '50%' : '25%'; ?>%;">
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Notes -->
                    <div class="info-card">
                        <h5 class="mb-3"><i class="fas fa-sticky-note" style="color: var(--text-muted);"></i> Repair Notes</h5>
                        <form method="POST">
                            <div class="mb-3">
                                <textarea name="note" class="form-control form-control-dark" rows="3" placeholder="Add work notes, issues found, or special instructions..."></textarea>
                            </div>
                            <button type="submit" name="add_note" class="btn btn-secondary-custom">Add Note</button>
                        </form>
                        <?php if($repair['notes']): ?>
                            <hr style="border-color: var(--border-steel);">
                            <h6 style="color: var(--text-muted);">Notes History:</h6>
                            <div class="notes-history">
                                <?php echo nl2br(htmlspecialchars($repair['notes'])); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <!-- Parts Used -->
                    <div class="info-card">
                        <h5 class="mb-3"><i class="fas fa-microchip" style="color: #198754;"></i> Parts Used</h5>
                        <div class="table-responsive">
                            <table class="table table-parts">
                                <thead>
                                    <tr><th>Part</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                                </thead>
                                <tbody>
                                    <?php while($part = $used_parts->fetch_assoc()): ?>
                                        <tr>
                                            <td style="color: var(--text);"><?php echo htmlspecialchars($part['part_name']); ?></td>
                                            <td style="color: var(--text);"><?php echo $part['quantity']; ?></td>
                                            <td style="color: var(--text-muted);">$<?php echo number_format($part['price_at_time'], 2); ?></td>
                                            <td style="color: var(--text);">$<?php echo number_format($part['quantity'] * $part['price_at_time'], 2); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                    <?php if(count($parts_list) == 0): ?>
                                        <tr><td colspan="4" class="text-center" style="color: var(--text-muted); padding: 20px 0;">No parts added yet</td></tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="3" style="color: var(--text);">Parts Total</th>
                                        <th style="color: var(--text);">$<?php echo number_format($parts_total, 2); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                        <div class="alert-success-custom mt-3">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong style="color: #75b798;">Labor Cost:</strong>
                                    <h4 style="color: var(--text);">$<?php echo number_format($repair['labor_cost'] ?? 0, 2); ?></h4>
                                </div>
                                <div class="col-md-6 text-end">
                                    <strong style="color: #75b798;">Total Cost:</strong>
                                    <h4 style="color: var(--primary-color);">$<?php echo number_format($grand_total, 2); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Tips -->
                    <div class="info-card">
                        <h5 class="mb-3"><i class="fas fa-lightbulb" style="color: #0dcaf0;"></i> Quick Tips</h5>
                        <ul class="list-unstyled mb-0 list-tips">
                            <li><i class="fas fa-check-circle"></i> Keep detailed notes for customer reference</li>
                            <li><i class="fas fa-check-circle"></i> Update status regularly</li>
                            <li><i class="fas fa-check-circle"></i> Mark as completed only when fully done</li>
                            <li><i class="fas fa-check-circle"></i> Review parts used before finishing</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        menuToggle.addEventListener('click', function() { sidebar.classList.toggle('active'); });
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
