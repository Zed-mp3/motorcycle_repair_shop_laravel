﻿<?php
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$conn = getConnection();
$user_id = $_SESSION['user_id'];

// Get all bookings for the logged-in customer
$sql = "SELECT b.*, 
        r.id as repair_id, 
        r.status as repair_status,
        r.labor_cost,
        r.start_date,
        r.completion_date,
        (SELECT SUM(price_at_time * quantity) FROM repair_parts WHERE repair_id = r.id) as parts_cost
        FROM bookings b 
        LEFT JOIN repairs r ON b.id = r.booking_id 
        WHERE b.user_id = ? 
        ORDER BY b.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bookings = $stmt->get_result();

// Get statistics
$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
    SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
    COALESCE(SUM(estimated_cost), 0) as total_spent
    FROM bookings 
    WHERE user_id = ?";
$stmt = $conn->prepare($stats_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - MotoRepair Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-color: #e67e22;
            --primary-dark: #c8641a;
            --ink: #16171a;
            --surface: #202227;
            --surface-raised: #2a2c33;
            --chrome: #cfd3d8;
            --chrome-dim: #7d828a;
            --text: #edeff1;
            --text-muted: #9a9ea5;
            --border-steel: rgba(207, 211, 216, 0.12);
        }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--ink); color: var(--text); overflow-x: hidden; }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, var(--surface) 0%, var(--ink) 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.4);
            border-right: 1px solid var(--border-steel);
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-header h3 { margin: 0; font-size: 1.5rem; }
        .sidebar-header p { margin: 5px 0 0; font-size: 0.8rem; opacity: 0.7; }
        
        .sidebar-menu { padding: 20px 0; }
        
        .menu-item {
            padding: 12px 25px;
            margin: 5px 0;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
        }
        
        .menu-item:hover { background: rgba(255,255,255,0.08); color: white; padding-left: 30px; }
        .menu-item.active { background: linear-gradient(90deg, var(--primary-color), var(--primary-dark)); color: white; border-radius: 0 20px 20px 0; }
        .menu-item i { width: 25px; font-size: 1.2rem; }
        
        .main-content { margin-left: 280px; transition: all 0.3s; }
        
        .top-navbar {
            background: var(--surface);
            padding: 15px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border-steel);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .page-title { font-size: 1.2rem; font-weight: 600; color: var(--text); }
        .user-info { display: flex; align-items: center; gap: 15px; color: var(--text); }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            transition: transform 0.3s, border-color 0.3s;
            text-align: center;
        }
        
        .stat-card:hover { transform: translateY(-5px); border-color: var(--primary-color); }
        
        .booking-card {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            overflow: hidden;
            transition: all 0.3s;
            color: var(--text);
        }
        
        .booking-card:hover { box-shadow: 0 5px 20px rgba(0,0,0,0.5); }
        
        .booking-header {
            background: var(--surface-raised);
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-steel);
            cursor: pointer;
            color: var(--text);
        }
        
        .booking-body { padding: 20px; display: none; }
        .booking-body.show { display: block; }

        .booking-body .text-muted,
        .booking-body p.text-muted { color: var(--text-muted) !important; }

        .booking-body .table { color: var(--text); }
        .booking-body .table td, .booking-body .table th { border-color: var(--border-steel) !important; }

        .booking-body .bg-light {
            background-color: var(--surface-raised) !important;
            color: var(--text);
        }

        .booking-body .table-active { --bs-table-accent-bg: var(--surface-raised); color: var(--text); }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending { background: #4a3a1a; color: #f4c968; }
        .status-accepted { background: #1c3350; color: #8ec1ff; }
        .status-in_progress { background: #163a52; color: #7cc3ff; }
        .status-completed { background: #1c3d26; color: #7fdb9a; }
        .status-cancelled { background: #4a2020; color: #ff9b9b; }
        
        .progress { height: 8px; border-radius: 4px; background-color: var(--ink); }
        
        .filter-btn {
            padding: 8px 16px;
            margin-right: 10px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
            background: var(--surface-raised);
            color: var(--text-muted);
            border: 1px solid var(--border-steel);
            display: inline-block;
        }
        
        .filter-btn.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .sidebar { left: -280px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .menu-toggle { display: block; position: fixed; top: 15px; left: 15px; z-index: 1001; background: var(--primary-color); color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer; }
            .top-navbar { padding-left: 70px; }
            .stat-card { margin-bottom: 15px; }
        }
        @media (min-width: 769px) { .menu-toggle { display: none; } }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-motorcycle fa-2x mb-2"></i>
            <h3>MotoRepair Pro</h3>
            <p>Customer Portal</p>
        </div>
        <div class="sidebar-menu">
            <a href="home.php" class="menu-item"><i class="fas fa-home"></i><span>Home</span></a>
            <a href="book-service.php" class="menu-item"><i class="fas fa-calendar-alt"></i><span>Book Service</span></a>
            <a href="track-status.php" class="menu-item"><i class="fas fa-search"></i><span>Track Status</span></a>
            <a href="booking-status.php" class="menu-item active"><i class="fas fa-history"></i><span>My Bookings</span></a>
            <div style="border-top: 1px solid rgba(255,255,255,0.1); margin: 20px 25px;"></div>
            <a href="../logout.php" class="menu-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>

    <div class="main-content" id="mainContent">
        <div class="top-navbar">
            <div class="page-title"><i class="fas fa-history text-primary"></i> My Bookings</div>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="container mt-4">
            <!-- Statistics Cards -->
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <h3 class="text-primary mb-0"><?php echo $stats['total'] ?? 0; ?></h3>
                        <small class="text-muted">Total Bookings</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <h3 class="text-warning mb-0"><?php echo $stats['pending'] ?? 0; ?></h3>
                        <small class="text-muted">Pending</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <h3 class="text-info mb-0"><?php echo ($stats['accepted'] ?? 0) + ($stats['in_progress'] ?? 0); ?></h3>
                        <small class="text-muted">In Progress</small>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <h3 class="text-success mb-0"><?php echo $stats['completed'] ?? 0; ?></h3>
                        <small class="text-muted">Completed</small>
                    </div>
                </div>
            </div>

            <!-- Filter Buttons -->
            <div class="mb-4">
                <span class="filter-btn active" data-filter="all">All</span>
                <span class="filter-btn" data-filter="pending">Pending</span>
                <span class="filter-btn" data-filter="accepted">Accepted</span>
                <span class="filter-btn" data-filter="in_progress">In Progress</span>
                <span class="filter-btn" data-filter="completed">Completed</span>
                <span class="filter-btn" data-filter="cancelled">Cancelled</span>
            </div>

            <!-- Bookings List -->
            <?php if($bookings->num_rows > 0): ?>
                <?php while($booking = $bookings->fetch_assoc()): 
                    $status_class = '';
                    switch($booking['status']) {
                        case 'pending': $status_class = 'status-pending'; break;
                        case 'accepted': $status_class = 'status-accepted'; break;
                        case 'in_progress': $status_class = 'status-in_progress'; break;
                        case 'completed': $status_class = 'status-completed'; break;
                        case 'cancelled': $status_class = 'status-cancelled'; break;
                    }
                    
                    $progress_percent = 0;
                    switch($booking['status']) {
                        case 'pending': $progress_percent = 25; break;
                        case 'accepted': $progress_percent = 50; break;
                        case 'in_progress': $progress_percent = 75; break;
                        case 'completed': $progress_percent = 100; break;
                    }
                    
                    $total_cost = ($booking['labor_cost'] ?? 0) + ($booking['parts_cost'] ?? 0);
                ?>
                <div class="booking-card" data-status="<?php echo $booking['status']; ?>">
                    <div class="booking-header" onclick="toggleBooking(<?php echo $booking['id']; ?>)">
                        <div class="row align-items-center">
                            <div class="col-md-3">
                                <strong><i class="fas fa-ticket-alt"></i> <?php echo $booking['booking_id']; ?></strong>
                            </div>
                            <div class="col-md-3">
                                <i class="fas fa-motorcycle"></i> <?php echo htmlspecialchars($booking['motorcycle_model']); ?>
                            </div>
                            <div class="col-md-2">
                                <span class="status-badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $booking['status'])); ?>
                                </span>
                            </div>
                            <div class="col-md-2">
                                <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($booking['created_at'])); ?>
                            </div>
                            <div class="col-md-2 text-end">
                                <i class="fas fa-chevron-down"></i>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="progress">
                                    <div class="progress-bar bg-<?php echo $progress_percent == 100 ? 'success' : 'primary'; ?>" 
                                         style="width: <?php echo $progress_percent; ?>%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="booking-body" id="booking-<?php echo $booking['id']; ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <h6><i class="fas fa-info-circle"></i> Service Details</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <td width="40%"><strong>Service Type:</strong></td>
                                        <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Problem:</strong></td>
                                        <td><?php echo htmlspecialchars($booking['problem_description']) ?: 'Not specified'; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Preferred Date:</strong></td>
                                        <td><?php echo date('F d, Y', strtotime($booking['preferred_date'])); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Queue Number:</strong></td>
                                        <td><span class="badge bg-secondary">#<?php echo $booking['queue_no']; ?></span></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h6><i class="fas fa-chart-line"></i> Progress Timeline</h6>
                                <div class="timeline small">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>ðŸ“‹ Booked</span>
                                        <span>âœ… Accepted</span>
                                        <span>ðŸ”§ In Progress</span>
                                        <span>ðŸŽ‰ Completed</span>
                                    </div>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar bg-success" style="width: <?php echo $progress_percent; ?>%">
                                            <?php echo $progress_percent; ?>%
                                        </div>
                                    </div>
                                </div>
                                
                                <?php if($booking['start_date']): ?>
                                <div class="mt-3">
                                    <small><i class="fas fa-play-circle text-success"></i> Started: <?php echo date('M d, Y', strtotime($booking['start_date'])); ?></small><br>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($booking['completion_date']): ?>
                                <div>
                                    <small><i class="fas fa-check-circle text-success"></i> Completed: <?php echo date('M d, Y', strtotime($booking['completion_date'])); ?></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h6><i class="fas fa-microchip"></i> Parts Used</h6>
                                <?php
                                $parts_sql = "SELECT rp.*, p.part_name 
                                              FROM repair_parts rp 
                                              JOIN parts p ON rp.part_id = p.id 
                                              WHERE rp.repair_id = ?";
                                $parts_stmt = $conn->prepare($parts_sql);
                                $parts_stmt->bind_param("i", $booking['repair_id']);
                                $parts_stmt->execute();
                                $parts_result = $parts_stmt->get_result();
                                
                                if($parts_result->num_rows > 0):
                                ?>
                                <table class="table table-sm">
                                    <thead>
                                        <tr><th>Part</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                                    </thead>
                                    <tbody>
                                        <?php while($part = $parts_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($part['part_name']); ?></td>
                                            <td><?php echo $part['quantity']; ?></td>
                                            <td>$<?php echo number_format($part['price_at_time'], 2); ?></td>
                                            <td>$<?php echo number_format($part['quantity'] * $part['price_at_time'], 2); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                <p class="text-muted">No parts recorded yet</p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6><i class="fas fa-calculator"></i> Cost Summary</h6>
                                        <table class="table table-sm">
                                            <tr>
                                                <td width="50%"><strong>Parts Cost:</strong></td>
                                                <td class="text-end">$<?php echo number_format($booking['parts_cost'] ?? 0, 2); ?></td>
                                            </tr>
                                            <tr>
                                                <td><strong>Labor Cost:</strong></td>
                                                <td class="text-end">$<?php echo number_format($booking['labor_cost'] ?? 0, 2); ?></td>
                                            </tr>
                                            <tr class="table-active">
                                                <td><strong>Total Amount:</strong></td>
                                                <td class="text-end"><strong>$<?php echo number_format($total_cost, 2); ?></strong></td>
                                            </tr>
                                        </table>
                                        <?php if($booking['status'] == 'completed'): ?>
                                        <button onclick="window.open('../generate-invoice.php?booking_id=<?php echo $booking['booking_id']; ?>', '_blank')" 
                                                class="btn btn-success btn-sm w-100">
                                            <i class="fas fa-file-invoice"></i> Download Invoice
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if($booking['status'] == 'pending'): ?>
                        <div class="mt-3 text-end">
                            <button onclick="cancelBooking(<?php echo $booking['id']; ?>, '<?php echo $booking['booking_id']; ?>')" 
                                    class="btn btn-danger btn-sm">
                                <i class="fas fa-times"></i> Cancel Booking
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-calendar-alt fa-4x text-muted mb-3"></i>
                    <h4>No Bookings Yet</h4>
                    <p class="text-muted">You haven't made any service bookings yet.</p>
                    <a href="book-service.php" class="btn btn-primary">Book Your First Service</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Toggle booking details
        function toggleBooking(id) {
            const element = document.getElementById('booking-' + id);
            element.classList.toggle('show');
        }
        
        // Filter bookings
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                
                // Update active state
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Filter bookings
                document.querySelectorAll('.booking-card').forEach(card => {
                    if (filter === 'all' || card.getAttribute('data-status') === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
        
        // Cancel booking
        function cancelBooking(id, bookingId) {
            if (confirm('Are you sure you want to cancel booking ' + bookingId + '?')) {
                window.location.href = '../cancel-booking.php?id=' + id;
            }
        }
        
        // Mobile sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        
        if(menuToggle) {
            menuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('active');
            });
        }
        
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
        
        // Expand first booking by default
        const firstBooking = document.querySelector('.booking-body');
        if(firstBooking) {
            firstBooking.classList.add('show');
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
