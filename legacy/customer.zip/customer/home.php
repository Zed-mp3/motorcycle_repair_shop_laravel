﻿<?php
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoRepair Pro - Professional Motorcycle Repair</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-color: #e67e22;
            --primary-dark: #c8641a;
            --ink: #16171a;
            --surface: #202227;
            --surface-raised: #2a2c33;
            --chrome: #cfd3d8;
            --chrome-dim: #7d828a;
            --text: #edeff1;
            --text-muted: #9a9ea5;
            --border-steel: rgba(207, 211, 216, 0.12);
        }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--ink); color: var(--text); overflow-x: hidden; }
        
        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, var(--surface) 0%, var(--ink) 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.4);
            border-right: 1px solid var(--border-steel);
        }
        
        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        
        .sidebar-header h3 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .sidebar-header p {
            margin: 5px 0 0;
            font-size: 0.8rem;
            opacity: 0.7;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-item {
            padding: 12px 25px;
            margin: 5px 0;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
        }
        
        .menu-item:hover {
            background: rgba(255,255,255,0.08);
            color: white;
            padding-left: 30px;
        }
        
        .menu-item.active {
            background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
            color: white;
            border-radius: 0 20px 20px 0;
        }
        
        .menu-item i {
            width: 25px;
            font-size: 1.2rem;
        }
        
        .menu-item span {
            font-size: 1rem;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            transition: all 0.3s;
        }
        
        /* Top Navbar */
        .top-navbar {
            background: var(--surface);
            padding: 15px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border-steel);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .page-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            color: var(--text);
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        
        .dropdown-menu-custom {
            position: absolute;
            top: 60px;
            right: 20px;
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.5);
            display: none;
            z-index: 1000;
        }
        
        .dropdown-menu-custom.show {
            display: block;
        }
        
        /* Hero Section */
        .hero-section {
            position: relative;
            background: linear-gradient(135deg, #2c2f36, var(--ink) 70%);
            color: white;
            padding: 60px 0;
            text-align: center;
            overflow: hidden;
        }

        .hero-section::after {
            content: '';
            position: absolute;
            left: 0; right: 0; bottom: 0;
            height: 6px;
            background: repeating-linear-gradient(
                135deg,
                var(--primary-color) 0px, var(--primary-color) 14px,
                var(--ink) 14px, var(--ink) 28px
            );
        }
        
        .hero-section h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        
        /* Service Cards */
        .service-card {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            transition: transform 0.3s, border-color 0.3s;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        
        .service-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary-color);
            box-shadow: 0 5px 20px rgba(0,0,0,0.5);
        }
        
        .service-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 1.8rem;
        }
        
        /* Footer */
        .footer {
            background: var(--surface);
            border-top: 1px solid var(--border-steel);
            color: var(--text);
            padding: 30px 0;
            margin-top: 50px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                left: -280px;
            }
            .sidebar.active {
                left: 0;
            }
            .main-content {
                margin-left: 0;
            }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                z-index: 1001;
                background: #e67e22;
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            .hero-section h1 {
                font-size: 1.8rem;
            }
            .top-navbar {
                padding-left: 70px;
            }
        }
        
        @media (min-width: 769px) {
            .menu-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-motorcycle fa-2x mb-2"></i>
            <h3>MotoRepair Pro</h3>
            <p>Customer Portal</p>
        </div>
        <div class="sidebar-menu">
            <a href="home.php" class="menu-item active">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <a href="book-service.php" class="menu-item">
                <i class="fas fa-calendar-alt"></i>
                <span>Book Service</span>
            </a>
            <a href="track-status.php" class="menu-item">
                <i class="fas fa-search"></i>
                <span>Track Status</span>
            </a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="booking-status.php" class="menu-item">
                    <i class="fas fa-history"></i>
                    <span>My Bookings</span>
                </a>
                <div style="border-top: 1px solid rgba(255,255,255,0.1); margin: 20px 25px;"></div>
                <a href="../logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            <?php else: ?>
                <div style="border-top: 1px solid rgba(255,255,255,0.1); margin: 20px 25px;"></div>
                <a href="../login.php" class="menu-item">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login / Register</span>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Mobile Toggle -->
    <button class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-motorcycle text-primary"></i> Welcome to MotoRepair Pro
            </div>
            <div class="user-info">
                <span>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                    <?php else: ?>
                        Guest User
                    <?php endif; ?>
                </span>
                <div class="user-avatar" onclick="toggleDropdown()">
                    <?php echo isset($_SESSION['user_name']) ? strtoupper(substr($_SESSION['user_name'], 0, 1)) : 'G'; ?>
                </div>
            </div>
        </div>

        <!-- Hero Section -->
        <div class="hero-section">
            <div class="container">
                <h1>Expert Motorcycle Repair Services</h1>
                <p class="lead">Fast, Reliable, and Affordable repairs for all motorcycle brands</p>
                <a href="book-service.php" class="btn btn-light btn-lg mt-3">
                    <i class="fas fa-calendar-alt"></i> Book a Service Now
                </a>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12 text-center mb-4">
                    <h2>Our Services</h2>
                    <p>Professional repair and maintenance services for your motorcycle</p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-engine"></i>
                        </div>
                        <h5>Engine Repair</h5>
                        <p>Complete engine overhaul, top-end rebuild, and performance tuning</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-oil-can"></i>
                        </div>
                        <h5>Oil Change</h5>
                        <p>Regular oil change and filter replacement for engine longevity</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <h5>Electrical Fix</h5>
                        <p>Wiring repair, battery replacement, and lighting system fixes</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-car-side"></i>
                        </div>
                        <h5>Brake Repair</h5>
                        <p>Brake pad replacement, caliper repair, and brake fluid service</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <h5>Tire Change</h5>
                        <p>New tire fitting, balancing, and tube replacement</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="service-card">
                        <div class="service-icon">
                            <i class="fas fa-tools"></i>
                        </div>
                        <h5>General Maintenance</h5>
                        <p>Complete inspection, chain adjustment, and preventive maintenance</p>
                    </div>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="service-card" style="background: linear-gradient(135deg, #e67e22, #f39c12); color: white;">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h3>Why Choose MotoRepair Pro?</h3>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check-circle"></i> Certified mechanics with 10+ years experience</li>
                                    <li><i class="fas fa-check-circle"></i> Genuine spare parts guaranteed</li>
                                    <li><i class="fas fa-check-circle"></i> Quick turnaround time</li>
                                    <li><i class="fas fa-check-circle"></i> Competitive pricing</li>
                                    <li><i class="fas fa-check-circle"></i> 30-day warranty on all repairs</li>
                                </ul>
                            </div>
                            <div class="col-md-6 text-center">
                                <h3>Opening Hours</h3>
                                <p>
                                    Monday - Friday: 8:00 AM - 7:00 PM<br>
                                    Saturday: 9:00 AM - 5:00 PM<br>
                                    Sunday: Closed<br>
                                    <strong>Emergency repairs available 24/7</strong>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <div class="container text-center">
                <p>&copy; 2024 MotoRepair Pro. All rights reserved.</p>
                <p>
                    <small>
                        <i class="fas fa-phone"></i> (555) 123-4567 &nbsp;|&nbsp;
                        <i class="fas fa-envelope"></i> info@motorepair.com
                    </small>
                </p>
            </div>
        </div>
    </div>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('userDropdown');
            const avatar = document.querySelector('.user-avatar');
            if (dropdown && !avatar.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Mobile sidebar toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        
        menuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
