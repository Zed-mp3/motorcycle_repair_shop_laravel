﻿<?php
require_once __DIR__ . '/../bootstrap.php';
// inventory.php - Redesigned with dark theme
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$conn = getConnection();

if (isset($_POST['save_part'])) {
    $id = $_POST['part_id'] ?? 0;
    $part_name = $_POST['part_name'];
    $description = $_POST['description'];
    $stock = $_POST['stock_quantity'];
    $price = $_POST['unit_price'];
    
    if ($id > 0) {
        $sql = "UPDATE parts SET part_name=?, description=?, stock_quantity=?, unit_price=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssidi", $part_name, $description, $stock, $price, $id);
    } else {
        $sql = "INSERT INTO parts (part_name, description, stock_quantity, unit_price) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssid", $part_name, $description, $stock, $price);
    }
    
    if ($stmt->execute()) {
        echo "<script>alert('Part saved successfully'); window.location.href='inventory.php';</script>";
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM parts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: inventory.php");
    exit();
}

$parts = $conn->query("SELECT * FROM parts ORDER BY part_name");
$edit_part = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = $conn->query("SELECT * FROM parts WHERE id = $id");
    $edit_part = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-color: #e67e22;
            --primary-dark: #c8641a;
            --ink: #16171a;
            --surface: #202227;
            --surface-raised: #2a2c33;
            --chrome: #cfd3d8;
            --chrome-dim: #7d828a;
            --text: #edeff1;
            --text-muted: #9a9ea5;
            --border-steel: rgba(207, 211, 216, 0.12);
        }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--ink); color: var(--text); overflow-x: hidden; }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, var(--surface) 0%, var(--ink) 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.4);
            border-right: 1px solid var(--border-steel);
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid var(--border-steel);
            text-align: center;
        }

        .sidebar-header h3 { margin: 0; font-size: 1.5rem; color: var(--text); }
        .sidebar-header p { margin: 5px 0 0; font-size: 0.8rem; opacity: 0.7; color: var(--text-muted); }

        .sidebar-menu { padding: 20px 0; }

        .menu-item {
            padding: 12px 25px;
            margin: 5px 0;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-left: 3px solid transparent;
        }

        .menu-item:hover { background: rgba(255,255,255,0.06); color: white; border-left-color: var(--primary-color); }
        .menu-item.active { background: rgba(230, 126, 34, 0.15); color: var(--primary-color); border-left-color: var(--primary-color); }
        .menu-item i { width: 25px; font-size: 1.2rem; }

        .main-content { margin-left: 280px; transition: all 0.3s; }

        .top-navbar {
            background: var(--surface);
            padding: 15px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border-steel);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 99;
        }

        .page-title { font-size: 1.2rem; font-weight: 600; color: var(--text); }
        .user-info { display: flex; align-items: center; gap: 15px; color: var(--text); }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .card-custom {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }

        .card-custom h5 { color: var(--text); }

        .form-control-dark {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
        }
        .form-control-dark:focus {
            background: var(--surface-raised);
            border-color: var(--primary-color);
            color: var(--text);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }
        .form-control-dark::placeholder { color: var(--text-muted); }

        .btn-primary-custom {
            background: var(--primary-color);
            border: none;
            color: white;
            border-radius: 8px;
            padding: 8px 20px;
            transition: all 0.2s;
            width: 100%;
        }
        .btn-primary-custom:hover { background: var(--primary-dark); color: white; }

        .btn-secondary-custom {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
            padding: 8px 20px;
            transition: all 0.2s;
            width: 100%;
            margin-top: 8px;
        }
        .btn-secondary-custom:hover { background: var(--border-steel); color: white; }

        .btn-warning-custom {
            background: #ffc107;
            border: none;
            color: #000;
            border-radius: 6px;
            padding: 5px 12px;
            font-size: 13px;
            transition: all 0.2s;
        }
        .btn-warning-custom:hover { background: #e0a800; color: #000; }

        .btn-danger-custom {
            background: #dc3545;
            border: none;
            color: white;
            border-radius: 6px;
            padding: 5px 12px;
            font-size: 13px;
            transition: all 0.2s;
        }
        .btn-danger-custom:hover { background: #bb2d3b; color: white; }

        .table-custom {
            color: var(--text);
            margin-bottom: 0;
        }
        .table-custom thead th {
            border-bottom: 2px solid var(--border-steel);
            color: var(--text-muted);
            font-weight: 500;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table-custom tbody td {
            border-bottom: 1px solid var(--border-steel);
            vertical-align: middle;
            padding: 12px 10px;
        }
        .table-custom tbody tr:hover { background: rgba(255,255,255,0.03); }
        .table-custom tbody tr:last-child td { border-bottom: none; }

        .text-muted-custom { color: var(--text-muted); }

        @media (max-width: 768px) {
            .sidebar { left: -280px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                z-index: 1001;
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 6px;
                cursor: pointer;
            }
            .top-navbar { padding-left: 70px; }
        }
        @media (min-width: 769px) { .menu-toggle { display: none; } }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-motorcycle fa-2x mb-2" style="color: var(--primary-color);"></i>
            <h3>MotoRepair Pro</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="jobs.php" class="menu-item"><i class="fas fa-tasks"></i><span>Job List</span></a>
            <a href="assign-mechanic.php" class="menu-item"><i class="fas fa-user-plus"></i><span>Assign Mechanic</span></a>
            <a href="inventory.php" class="menu-item active"><i class="fas fa-boxes"></i><span>Inventory</span></a>
            <a href="mechanics.php" class="menu-item"><i class="fas fa-users"></i><span>Mechanics</span></a>
            <a href="customers.php" class="menu-item"><i class="fas fa-users"></i><span>Customers</span></a>
            <a href="reports.php" class="menu-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
            <div style="border-top: 1px solid var(--border-steel); margin: 20px 25px;"></div>
            <a href="../logout.php" class="menu-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>

    <div class="main-content" id="mainContent">
        <div class="top-navbar">
            <div class="page-title"><i class="fas fa-boxes" style="color: var(--primary-color);"></i> Inventory Management</div>
            <div class="user-info">
                <span>Welcome, <?php echo $_SESSION['user_name']; ?></span>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="container mt-4">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card-custom">
                        <h5><i class="fas fa-plus" style="color: var(--primary-color);"></i> <?php echo $edit_part ? 'Edit' : 'Add'; ?> Part</h5>
                        <form method="POST">
                            <input type="hidden" name="part_id" value="<?php echo $edit_part['id'] ?? 0; ?>">
                            <div class="mb-3">
                                <label style="color: var(--text-muted); font-size: 14px;">Part Name *</label>
                                <input type="text" name="part_name" class="form-control form-control-dark" value="<?php echo $edit_part['part_name'] ?? ''; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label style="color: var(--text-muted); font-size: 14px;">Description</label>
                                <textarea name="description" class="form-control form-control-dark" rows="2"><?php echo $edit_part['description'] ?? ''; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label style="color: var(--text-muted); font-size: 14px;">Stock Quantity *</label>
                                <input type="number" name="stock_quantity" class="form-control form-control-dark" value="<?php echo $edit_part['stock_quantity'] ?? 0; ?>" required min="0">
                            </div>
                            <div class="mb-3">
                                <label style="color: var(--text-muted); font-size: 14px;">Unit Price ($) *</label>
                                <input type="number" name="unit_price" class="form-control form-control-dark" step="0.01" value="<?php echo $edit_part['unit_price'] ?? 0; ?>" required>
                            </div>
                            <button type="submit" name="save_part" class="btn btn-primary-custom"><i class="fas fa-save"></i> <?php echo $edit_part ? 'Update' : 'Save'; ?> Part</button>
                            <?php if($edit_part): ?>
                                <a href="inventory.php" class="btn btn-secondary-custom">Cancel Edit</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="card-custom">
                        <h5><i class="fas fa-list" style="color: var(--primary-color);"></i> Parts Inventory</h5>
                        <div class="table-responsive">
                            <table class="table table-custom">
                                <thead>
                                    <tr>
                                        <th>Part Name</th>
                                        <th>Stock</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($part = $parts->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <strong style="color: var(--text);"><?php echo $part['part_name']; ?></strong><br>
                                                <small class="text-muted-custom"><?php echo $part['description']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge" style="background: <?php echo $part['stock_quantity'] < 10 ? '#dc3545' : ($part['stock_quantity'] < 30 ? '#ffc107' : '#198754'); ?>; color: <?php echo $part['stock_quantity'] < 30 ? '#000' : '#fff'; ?>;">
                                                    <?php echo $part['stock_quantity']; ?> units
                                                </span>
                                            </td>
                                            <td style="color: var(--text);">$<?php echo number_format($part['unit_price'], 2); ?></td>
                                            <td>
                                                <a href="?edit=<?php echo $part['id']; ?>" class="btn-warning-custom"><i class="fas fa-edit"></i></a>
                                                <a href="?delete=<?php echo $part['id']; ?>" class="btn-danger-custom" onclick="return confirm('Delete this part?')"><i class="fas fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                    <?php if($parts->num_rows == 0): ?>
                                        <tr>
                                            <td colspan="4" class="text-center text-muted-custom" style="padding: 40px 0;">
                                                <i class="fas fa-boxes fa-2x d-block mb-2" style="color: var(--text-muted);"></i>
                                                No parts in inventory
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        menuToggle.addEventListener('click', function() { sidebar.classList.toggle('active'); });
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
