﻿<?php
require_once __DIR__ . '/../bootstrap.php';
// jobs.php - Redesigned with dark theme
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$conn = getConnection();

if (isset($_POST['update_status'])) {
    $booking_id = $_POST['booking_id'];
    $new_status = $_POST['status'];
    
    $sql = "UPDATE bookings SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $new_status, $booking_id);
    $stmt->execute();
    
    if ($new_status == 'in_progress') {
        $sql = "INSERT INTO repairs (booking_id, status, start_date) VALUES (?, 'in_progress', CURDATE()) 
                ON DUPLICATE KEY UPDATE status = 'in_progress', start_date = CURDATE()";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
    } elseif ($new_status == 'completed') {
        $sql = "UPDATE repairs SET status = 'completed', completion_date = CURDATE() WHERE booking_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $booking_id);
        $stmt->execute();
    }
    
    header("Location: jobs.php");
    exit();
}

$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

$sql = "SELECT b.*, u.name as user_name FROM bookings b 
        LEFT JOIN users u ON b.user_id = u.id 
        WHERE 1=1";
if ($status_filter != 'all') {
    $sql .= " AND b.status = '$status_filter'";
}
if ($search) {
    $sql .= " AND (b.full_name LIKE '%$search%' OR b.booking_id LIKE '%$search%' OR b.motorcycle_model LIKE '%$search%')";
}
$sql .= " ORDER BY b.created_at DESC";
$bookings = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Management - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-color: #e67e22;
            --primary-dark: #c8641a;
            --ink: #16171a;
            --surface: #202227;
            --surface-raised: #2a2c33;
            --chrome: #cfd3d8;
            --chrome-dim: #7d828a;
            --text: #edeff1;
            --text-muted: #9a9ea5;
            --border-steel: rgba(207, 211, 216, 0.12);
        }

        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--ink); color: var(--text); overflow-x: hidden; }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: linear-gradient(135deg, var(--surface) 0%, var(--ink) 100%);
            color: white;
            transition: all 0.3s;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.4);
            border-right: 1px solid var(--border-steel);
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid var(--border-steel);
            text-align: center;
        }

        .sidebar-header h3 { margin: 0; font-size: 1.5rem; color: var(--text); }
        .sidebar-header p { margin: 5px 0 0; font-size: 0.8rem; opacity: 0.7; color: var(--text-muted); }

        .sidebar-menu { padding: 20px 0; }

        .menu-item {
            padding: 12px 25px;
            margin: 5px 0;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            border-left: 3px solid transparent;
        }

        .menu-item:hover { background: rgba(255,255,255,0.06); color: white; border-left-color: var(--primary-color); }
        .menu-item.active { background: rgba(230, 126, 34, 0.15); color: var(--primary-color); border-left-color: var(--primary-color); }
        .menu-item i { width: 25px; font-size: 1.2rem; }

        .main-content { margin-left: 280px; transition: all 0.3s; }

        .top-navbar {
            background: var(--surface);
            padding: 15px 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            border-bottom: 1px solid var(--border-steel);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 99;
        }

        .page-title { font-size: 1.2rem; font-weight: 600; color: var(--text); }
        .user-info { display: flex; align-items: center; gap: 15px; color: var(--text); }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .table-container {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .table-custom {
            color: var(--text);
            margin-bottom: 0;
        }
        .table-custom thead th {
            border-bottom: 2px solid var(--border-steel);
            color: var(--text-muted);
            font-weight: 500;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .table-custom tbody td {
            border-bottom: 1px solid var(--border-steel);
            vertical-align: middle;
            padding: 12px 10px;
        }
        .table-custom tbody tr:hover { background: rgba(255,255,255,0.03); }
        .table-custom tbody tr:last-child td { border-bottom: none; }

        .form-control-dark {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
        }
        .form-control-dark:focus {
            background: var(--surface-raised);
            border-color: var(--primary-color);
            color: var(--text);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }
        .form-control-dark::placeholder { color: var(--text-muted); }

        .form-select-dark {
            background: var(--surface-raised);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 8px;
        }
        .form-select-dark:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(230, 126, 34, 0.25);
        }

        .btn-primary-custom {
            background: var(--primary-color);
            border: none;
            color: white;
            border-radius: 8px;
            padding: 8px 20px;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover { background: var(--primary-dark); color: white; }

        .btn-info-custom {
            background: #0d6efd;
            border: none;
            color: white;
            border-radius: 6px;
            padding: 5px 12px;
            font-size: 13px;
            transition: all 0.2s;
        }
        .btn-info-custom:hover { background: #0b5ed7; color: white; }

        .btn-edit-custom {
            background: #ffc107;
            border: none;
            color: #000;
            border-radius: 6px;
            padding: 5px 12px;
            font-size: 13px;
            transition: all 0.2s;
        }
        .btn-edit-custom:hover { background: #e0a800; color: #000; }

        .btn-success-custom {
            background: #198754;
            border: none;
            color: white;
            border-radius: 6px;
            padding: 5px 12px;
            font-size: 13px;
            transition: all 0.2s;
        }
        .btn-success-custom:hover { background: #157347; color: white; }

        .modal-content-custom {
            background: var(--surface);
            border: 1px solid var(--border-steel);
            color: var(--text);
            border-radius: 12px;
        }
        .modal-content-custom .modal-header {
            border-bottom: 1px solid var(--border-steel);
        }
        .modal-content-custom .modal-footer {
            border-top: 1px solid var(--border-steel);
        }
        .modal-content-custom .btn-close {
            filter: invert(1);
        }

        .text-muted-custom { color: var(--text-muted); }

        @media (max-width: 768px) {
            .sidebar { left: -280px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .menu-toggle {
                display: block;
                position: fixed;
                top: 15px;
                left: 15px;
                z-index: 1001;
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 6px;
                cursor: pointer;
            }
            .top-navbar { padding-left: 70px; }
            .table-responsive-custom { overflow-x: auto; }
        }
        @media (min-width: 769px) { .menu-toggle { display: none; } }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-motorcycle fa-2x mb-2" style="color: var(--primary-color);"></i>
            <h3>MotoRepair Pro</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
            <a href="jobs.php" class="menu-item active"><i class="fas fa-tasks"></i><span>Job List</span></a>
            <a href="assign-mechanic.php" class="menu-item"><i class="fas fa-user-plus"></i><span>Assign Mechanic</span></a>
            <a href="inventory.php" class="menu-item"><i class="fas fa-boxes"></i><span>Inventory</span></a>
            <a href="mechanics.php" class="menu-item"><i class="fas fa-users"></i><span>Mechanics</span></a>
            <a href="customers.php" class="menu-item"><i class="fas fa-users"></i><span>Customers</span></a>
            <a href="reports.php" class="menu-item"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
            <div style="border-top: 1px solid var(--border-steel); margin: 20px 25px;"></div>
            <a href="../logout.php" class="menu-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
        </div>
    </div>

    <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>

    <div class="main-content" id="mainContent">
        <div class="top-navbar">
            <div class="page-title"><i class="fas fa-tasks" style="color: var(--primary-color);"></i> Job Management</div>
            <div class="user-info">
                <span>Welcome, <?php echo $_SESSION['user_name']; ?></span>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="container mt-4">
            <div class="row mb-3">
                <div class="col-md-6">
                    <form method="GET" class="d-flex gap-2 flex-wrap">
                        <input type="text" name="search" class="form-control form-control-dark" placeholder="Search by name, ID, or model" value="<?php echo $search; ?>" style="flex:1; min-width:150px;">
                        <select name="status" class="form-control form-select-dark" style="width: auto; min-width:120px;">
                            <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Status</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="accepted" <?php echo $status_filter == 'accepted' ? 'selected' : ''; ?>>Accepted</option>
                            <option value="in_progress" <?php echo $status_filter == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                            <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        </select>
                        <button type="submit" class="btn btn-primary-custom">Filter</button>
                    </form>
                </div>
                <div class="col-md-6 text-end">
                    <a href="assign-mechanic.php" class="btn btn-primary-custom">
                        <i class="fas fa-user-plus"></i> Assign Mechanic
                    </a>
                </div>
            </div>

            <div class="table-container">
                <div class="table-responsive table-responsive-custom">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Customer</th>
                                <th>Motorcycle</th>
                                <th>Service</th>
                                <th>Queue</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($bookings->num_rows > 0): ?>
                                <?php while($row = $bookings->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong style="color: var(--text);"><?php echo $row['booking_id']; ?></strong></td>
                                        <td style="color: var(--text);"><?php echo $row['full_name']; ?></td>
                                        <td style="color: var(--text);"><?php echo $row['motorcycle_model']; ?></td>
                                        <td style="color: var(--text);"><?php echo $row['service_type']; ?></td>
                                        <td><span class="badge" style="background: var(--surface-raised); color: var(--text-muted);">#<?php echo $row['queue_no']; ?></span></td>
                                        <td>
                                            <span class="badge" style="background: <?php 
                                                echo $row['status'] == 'pending' ? '#ffc107' : 
                                                    ($row['status'] == 'accepted' ? '#0dcaf0' : 
                                                    ($row['status'] == 'in_progress' ? '#0d6efd' : '#198754')); 
                                                ?>; color: <?php echo $row['status'] == 'pending' ? '#000' : '#fff'; ?>;">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                        </td>
                                        <td style="color: var(--text-muted);"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                        <td>
                                            <button class="btn-info-custom" onclick="viewDetails(<?php echo $row['id']; ?>)"><i class="fas fa-eye"></i></button>
                                            <button class="btn-edit-custom" data-bs-toggle="modal" data-bs-target="#updateModal" onclick="setUpdateData(<?php echo $row['id']; ?>, '<?php echo $row['status']; ?>')"><i class="fas fa-edit"></i></button>
                                            <a href="repair-details.php?booking_id=<?php echo $row['id']; ?>" class="btn-success-custom"><i class="fas fa-wrench"></i></a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted-custom" style="padding: 40px 0;">
                                        <i class="fas fa-tasks fa-2x d-block mb-2" style="color: var(--text-muted);"></i>
                                        No bookings found
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content modal-content-custom">
                <div class="modal-header">
                    <h5 class="modal-title" style="color: var(--text);">Update Job Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="booking_id" id="update_booking_id">
                        <select name="status" id="update_status" class="form-control form-select-dark" required>
                            <option value="pending">Pending</option>
                            <option value="accepted">Accepted</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary-custom" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_status" class="btn btn-primary-custom">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        menuToggle.addEventListener('click', function() { sidebar.classList.toggle('active'); });
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
                    sidebar.classList.remove('active');
                }
            }
        });

        function setUpdateData(id, status) {
            document.getElementById('update_booking_id').value = id;
            document.getElementById('update_status').value = status;
        }

        function viewDetails(id) {
            window.location.href = 'repair-details.php?booking_id=' + id;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
